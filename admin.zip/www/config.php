<?php
    $hote='localhost';
    $port='3306';
    $nom_bd='webweek';
    $identifiant='root';
    $mot_de_passe='';
    $encodage='utf8';
    $options=array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES '.$encodage);
?>